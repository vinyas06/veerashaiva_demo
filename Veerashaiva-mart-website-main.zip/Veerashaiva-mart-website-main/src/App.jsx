import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Capabilities from './components/Capabilities';
import Subsidiaries from './components/Subsidiaries';
import Footer from './components/Footer';
import EnquiryModal from './components/EnquiryModal';
import BrandPage from './components/BrandPage';
import LogisticsPage from './components/LogisticsPage';
import './App.css';

function App() {
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/';
  const brandPaths = {
    '/blinker': 'blinker',
    '/niranthara': 'niranthara',
    '/veerashaiva-express-logistics': 'vel',
    '/veerashaiva-infotech-technology': 'infotech',
    '/coastal-king': 'coastalKing',
  };
  const selectedBrand = brandPaths[pathname] || new URLSearchParams(window.location.search).get('brand');

  if (selectedBrand === 'vel') {
    return <LogisticsPage />;
  }

  if (['niranthara', 'blinker', 'coastalKing', 'infotech'].includes(selectedBrand)) {
    return <BrandPage brand={selectedBrand} />;
  }

  return (
    <div className="app-shell">
      <Navbar onEnquire={() => setIsEnquiryOpen(true)} />
      <main className="site-main">
        <Hero onEnquire={() => setIsEnquiryOpen(true)} />
        <About />
        <Capabilities />
        <Subsidiaries />
      </main>
      <Footer />
      {isEnquiryOpen && <EnquiryModal onClose={() => setIsEnquiryOpen(false)} />}
    </div>
  );
}

export default App;
