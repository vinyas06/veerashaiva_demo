import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import OfflineGuard from './components/OfflineGuard.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <OfflineGuard><App /></OfflineGuard>
  </React.StrictMode>,
)

if ('serviceWorker' in navigator && (import.meta.env.PROD || ['localhost', '127.0.0.1'].includes(window.location.hostname))) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}))
}
