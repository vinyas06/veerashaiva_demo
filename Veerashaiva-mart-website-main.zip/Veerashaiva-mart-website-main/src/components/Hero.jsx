import { motion } from 'framer-motion';
import { ArrowDownRight, MessageCircle, Phone } from 'lucide-react';
import heroImage from '../assets/product-family-hero.png';
import './Hero.css';

const reveal = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
};

const Hero = ({ onEnquire }) => (
  <section id="home" className="hero">
    <img className="hero-image" src={heroImage} alt="The Veerashaiva Mart family of products" />
    <div className="hero-overlay" />
    <div className="hero-grain" aria-hidden="true" />

    <div className="container hero-container">
      <motion.div
        className="hero-content"
        initial="hidden"
        animate="visible"
        variants={{ visible: { transition: { staggerChildren: 0.12 } } }}
      >
        <motion.p className="eyebrow hero-eyebrow" variants={reveal}>
          Rooted in Udupi · Made for every day
        </motion.p>
        <motion.h1 variants={reveal}>
          A little more joy<br />
          <span>in every day.</span>
        </motion.h1>
        <motion.p className="hero-copy" variants={reveal}>
          From sparkling Blinker refreshments to Niranthara Magic masalas and pure coconut oil, our family of brands brings quality closer to home.
        </motion.p>
        <motion.div className="hero-actions" variants={reveal}>
          <a href="#brands" className="button button-primary">
            Explore our brands <ArrowDownRight size={18} aria-hidden="true" />
          </a>
          <a href="tel:+919155700900" className="button button-ghost">
            <Phone size={17} aria-hidden="true" /> +91 91557 00900
          </a>
          <button type="button" className="button button-enquiry" onClick={onEnquire}>
            <MessageCircle size={17} aria-hidden="true" /> Enquire Now
          </button>
        </motion.div>
      </motion.div>

      <motion.div
        className="hero-side-note"
        initial={{ opacity: 0, x: 24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.7, duration: 0.6 }}
      >
        <span>Based in</span>
        <strong>Udupi, Karnataka</strong>
        <i />
        <span>Since 2023</span>
      </motion.div>
    </div>
  </section>
);

export default Hero;
