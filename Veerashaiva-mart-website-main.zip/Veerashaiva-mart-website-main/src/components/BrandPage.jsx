import { ArrowLeft, ArrowUpRight, Phone, Sparkles } from 'lucide-react';
import blinkerLogo from '../assets/blinker_logo.png';
import coastalKingLogo from '../assets/coastal_king_logo.png';
import nirantharaLogo from '../assets/niranthara_logo.png';
import velLogo from '../assets/vel_logo_clean.png';
import infotechLogo from '../assets/veerashaiva_infotech_logo.png';
import './BrandPage.css';

const brands = {
  niranthara: {
    label: 'Niranthara Magic',
    kicker: 'Pure vegetarian masalas',
    title: <>Tradition,<br /><em>in every pinch.</em></>,
    copy: 'Thoughtfully blended masalas for the recipes that bring people together. Full flavour, familiar warmth and a little kitchen magic.',
    logo: nirantharaLogo,
    lead: '/product-photos/niranthara-garam-masala.jpeg',
    accent: 'spice',
    sectionTitle: <>A range with<br /><em>real character.</em></>,
    sectionCopy: 'Explore the products currently available from Niranthara Magic.',
    cards: [
      { name: 'Garam Masala', detail: 'A warming, aromatic blend for everyday curries and special recipes.', image: '/product-photos/niranthara-garam-masala.jpeg' },
      { name: 'Red Chilli Powder', detail: 'Rich colour and bold heat, blended for an unmistakable finish.', image: '/product-photos/niranthara-red-chilli.jpeg' },
      { name: 'Biryani Masala', detail: 'An inviting, fragrant blend for a perfectly memorable biryani.', image: '/product-photos/niranthara-biryani-masala.jpeg' },
    ],
  },
  blinker: {
    label: 'Blinker Beverages',
    kicker: 'Bright. Bubbly. Refreshing.',
    title: <>Open up<br /><em>something joyful.</em></>,
    copy: 'A refreshment made for the good moments. Discover lively flavours, sparkling personality and a bottle built to brighten your break.',
    logo: blinkerLogo,
    lead: '/product-photos/blinker-lime.jpeg',
    accent: 'fresh',
    sectionTitle: <>A range with<br /><em>real character.</em></>,
    sectionCopy: 'Explore the refreshing flavours currently available from Blinker Beverages.',
    cards: [
      { name: 'Jeera Masala', detail: 'Spiced, sparkling and full of character.', image: '/product-photos/blinker-jeera-masala.jpeg' },
      { name: 'Cola', detail: 'A classic cola with a bright Blinker twist.', image: '/product-photos/blinker-cola.jpeg' },
      { name: 'Orange', detail: 'Juicy citrus sparkle for a sunny lift.', image: '/product-photos/blinker-orange.jpeg' },
      { name: 'Lime', detail: 'Crisp lime refreshment with an energising edge.', image: '/product-photos/blinker-lime.jpeg' },
      { name: 'Lemon Lime', detail: 'A zesty lemon-lime sparkle, ready to share.', image: '/product-photos/blinker-lemon-lime.jpeg' },
    ],
  },
  vel: {
    label: 'Veerashaiva Express Logistics',
    kicker: 'Reliable logistics from Udupi',
    title: <>Moving business<br /><em>with care.</em></>,
    copy: 'Veerashaiva Express Logistics keeps products moving with fast, safe and on-time delivery that businesses can depend on.',
    logo: velLogo,
    lead: velLogo,
    leadMode: 'logo',
    accent: 'logistics',
    sectionTitle: <>Logistics that<br /><em>moves with you.</em></>,
    sectionCopy: 'Dependable support for the journeys that keep your business moving forward.',
    cards: [
      { name: 'Fast movement', detail: 'Responsive logistics support for products that need to go further.', image: velLogo, artMode: 'logo' },
      { name: 'Safe handling', detail: 'Careful movement focused on the products entrusted to us.', image: velLogo, artMode: 'logo' },
      { name: 'On-time delivery', detail: 'A reliable service built to keep business moving.', image: velLogo, artMode: 'logo' },
    ],
  },
  coastalKing: {
    label: 'Coastal King',
    kicker: 'South Indian spice blends',
    title: <>The taste of<br /><em>the coast.</em></>,
    copy: 'Coastal King brings the character of South Indian spice blends to the kitchen, with flavour inspired by the coast.',
    logo: coastalKingLogo,
    lead: coastalKingLogo,
    leadMode: 'logo',
    accent: 'coastal',
    sectionTitle: <>Flavour from<br /><em>the coast.</em></>,
    sectionCopy: 'A South Indian masala brand from the Veerashaiva Mart family.',
    cards: [
      { name: 'South Indian blends', detail: 'Masala blends with a flavour profile inspired by the coast.', image: coastalKingLogo, artMode: 'logo' },
      { name: 'Made for the kitchen', detail: 'A brand created to bring familiar South Indian flavour home.', image: coastalKingLogo, artMode: 'logo' },
      { name: 'Product availability', detail: 'Contact our team for the latest Coastal King product information.', image: coastalKingLogo, artMode: 'logo' },
    ],
  },
  infotech: {
    label: 'Veerashaiva Infotech Technology',
    kicker: 'Technology built around business',
    title: <>Ideas made<br /><em>digital.</em></>,
    copy: 'Practical, thoughtfully designed technology solutions that help businesses build a stronger digital presence and work with confidence.',
    logo: infotechLogo,
    lead: infotechLogo,
    leadMode: 'logo',
    accent: 'infotech',
    sectionKicker: 'How we can help',
    sectionTitle: <>Useful technology.<br /><em>Clear outcomes.</em></>,
    sectionCopy: 'A dependable technology partner for the digital needs of growing businesses.',
    contactKicker: 'Have an idea or a business need?',
    contactTitle: <>Let’s build something<br /><em>that works.</em></>,
    cards: [
      { name: 'Digital presence', detail: 'Professional web experiences that make your business easier to discover and trust.', image: infotechLogo, artMode: 'logo' },
      { name: 'Business solutions', detail: 'Practical technology shaped around real workflows, customers and business goals.', image: infotechLogo, artMode: 'logo' },
      { name: 'Reliable support', detail: 'Clear communication and dependable technology guidance as your needs evolve.', image: infotechLogo, artMode: 'logo' },
    ],
  },
};

const BrandPage = ({ brand }) => {
  const content = brands[brand];

  return (
    <main className={`brand-page ${content.accent}`}>
      <nav className="brand-nav container" aria-label="Brand page navigation">
        <a href="/" className="brand-back"><ArrowLeft size={17} aria-hidden="true" /> Veerashaiva Mart</a>
        <img src={content.logo} alt={content.label} />
        <a href="tel:+919155700900" className="brand-nav-call"><Phone size={16} aria-hidden="true" /> Call us</a>
      </nav>

      <section className="brand-hero container">
        <div className="brand-hero-copy">
          <p className="brand-kicker"><Sparkles size={15} aria-hidden="true" /> {content.kicker}</p>
          <h1>{content.title}</h1>
          <p>{content.copy}</p>
          <a className="brand-cta" href="#range">Discover more <ArrowUpRight size={18} aria-hidden="true" /></a>
        </div>
        <div className={`brand-lead-art ${content.leadMode === 'logo' ? 'is-logo' : ''}`}>
          <div className="brand-lead-glow" aria-hidden="true" />
          <img src={content.lead} alt={`${content.label} featured visual`} />
        </div>
      </section>

      <section id="range" className="brand-range">
        <div className="container">
          <div className="range-intro">
            <p className="brand-kicker">{content.sectionKicker || 'Made to be enjoyed'}</p>
            <h2>{content.sectionTitle}</h2>
            <p>{content.sectionCopy}</p>
          </div>
          <div className="product-grid">
            {content.cards.map((card, index) => (
              <article className="product-card" key={card.name}>
                <div className={`product-photo ${card.artMode === 'logo' ? 'is-logo' : ''}`}><img src={card.image} alt={card.name} loading={index > 1 ? 'lazy' : 'eager'} /></div>
                <div className="product-copy">
                  <span>{String(index + 1).padStart(2, '0')}</span>
                  <h3>{card.name}</h3>
                  <p>{card.detail}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="brand-contact container">
        <div>
          <p className="brand-kicker">{content.contactKicker || 'Want to stock our products?'}</p>
          <h2>{content.contactTitle || <>Let’s make every shelf<br /><em>more memorable.</em></>}</h2>
        </div>
        <a href="tel:+919155700900">Talk to our team <ArrowUpRight size={18} aria-hidden="true" /></a>
      </section>

      <footer className="brand-footer container">
        <span>© {new Date().getFullYear()} Veerashaiva Mart</span>
        <a href="/">Back to Veerashaiva Mart</a>
      </footer>
    </main>
  );
};

export default BrandPage;
