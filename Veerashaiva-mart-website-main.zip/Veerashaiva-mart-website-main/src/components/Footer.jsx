import { ArrowUpRight, MapPin, Phone } from 'lucide-react';
import mainLogo from '../assets/veerashaiva_logo.png';
import './Footer.css';

const Footer = () => (
  <footer id="contact" className="footer">
    <div className="container">
      <div className="contact-band">
        <div>
          <p className="eyebrow">Let’s talk</p>
          <h2>Made to move<br /><em>forward, together.</em></h2>
        </div>
        <a className="contact-phone" href="tel:+919155700900">
          <span>Call Veerashaiva Mart</span>
          <strong>+91 91557 00900 <ArrowUpRight size={21} aria-hidden="true" /></strong>
        </a>
      </div>

      <div className="footer-content">
        <div className="footer-brand">
          <div className="footer-brand-lockup"><img src={mainLogo} alt="Veerashaiva Mart logo" /><span>Veerashaiva<br />Mart</span></div>
          <p>Manufacturing thoughtful essentials and delivering dependable service from Udupi, Karnataka.</p>
        </div>
        <div className="footer-links">
          <h3>Explore</h3>
          <a href="#about">About us</a>
          <a href="#businesses">Our businesses</a>
          <a href="#brands">Our brands</a>
        </div>
        <address className="footer-contact">
          <h3>Visit us</h3>
          <a href="https://www.google.com/maps/search/?api=1&query=4-70N(1)(2)%2C+Veerashaiva+Nivasa+Building%2C+Near+Bank+of+Baroda%2C+Kolalagiri%2C+Havanje%2C+Udupi%2C+Karnataka+576124" target="_blank" rel="noreferrer">
            <MapPin size={18} aria-hidden="true" />
            <span>4-70N(1)(2), Veerashaiva Nivasa Building,<br />near Bank of Baroda, Kolalagiri, Havanje,<br />Udupi, Karnataka – 576124</span>
          </a>
          <a href="tel:+919155700900"><Phone size={17} aria-hidden="true" /> +91 91557 00900</a>
        </address>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Veerashaiva Mart. All rights reserved.</span>
        <span>Quality · Care · Community</span>
      </div>
    </div>
  </footer>
);

export default Footer;
