import { useEffect, useState } from 'react';
import { Menu, MessageCircle, Phone, X } from 'lucide-react';
import mainLogo from '../assets/veerashaiva_logo.png';
import './Navbar.css';

const navItems = [
  { href: '#about', label: 'About' },
  { href: '#businesses', label: 'Businesses' },
  { href: '#brands', label: 'Brands' },
  { href: '#contact', label: 'Contact' },
];

const Navbar = ({ onEnquire }) => {
  const [scrolled, setScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setIsOpen(false);

  return (
    <header className={`navbar ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="nav-container">
        <a href="#home" className="brand" aria-label="Veerashaiva Mart home" onClick={closeMenu}>
          <img src={mainLogo} alt="Veerashaiva Mart" className="navbar-logo" />
          <span>Veerashaiva<br />Mart</span>
        </a>
        <nav className="desktop-menu" aria-label="Main navigation">
          {navItems.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}
        </nav>
        <button className="nav-enquire" type="button" onClick={onEnquire}><MessageCircle size={15} aria-hidden="true" /> Enquire Now</button>
        <a className="nav-call" href="tel:+919155700900"><Phone size={15} aria-hidden="true" /> Call us</a>
        <button className="mobile-toggle" type="button" aria-label="Toggle menu" aria-expanded={isOpen} onClick={() => setIsOpen((open) => !open)}>
          {isOpen ? <X size={22} /> : <Menu size={23} />}
        </button>
      </div>
      {isOpen && (
        <nav className="mobile-menu" aria-label="Mobile navigation">
          {navItems.map((item) => <a key={item.href} href={item.href} onClick={closeMenu}>{item.label}</a>)}
          <button type="button" onClick={() => { closeMenu(); onEnquire(); }}>Enquire Now</button>
          <a href="tel:+919155700900" onClick={closeMenu}>+91 91557 00900</a>
        </nav>
      )}
    </header>
  );
};

export default Navbar;
