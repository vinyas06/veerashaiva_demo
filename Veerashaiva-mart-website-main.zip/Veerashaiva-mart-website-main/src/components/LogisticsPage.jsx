import { ArrowLeft, ArrowRight, CheckCircle2, Clock3, Headphones, MapPinned, PackageCheck, Phone, ShieldCheck, Truck } from 'lucide-react';
import velLogo from '../assets/vel_logo_clean.png';
import heroImage from '../assets/vel-logistics-hero.png';
import './LogisticsPage.css';

const promises = [
  { icon: Clock3, title: 'On-time commitment', copy: 'Planned dispatch and dependable delivery timelines that help your business stay on schedule.' },
  { icon: ShieldCheck, title: 'Safe handling', copy: 'Your goods are handled responsibly, with care from pickup through final delivery.' },
  { icon: MapPinned, title: 'All-India movement', copy: 'Flexible road logistics support for local, regional and long-distance requirements.' },
  { icon: Headphones, title: 'Responsive support', copy: 'Clear communication and an approachable team whenever you need an update.' },
];

const services = [
  { number: '01', title: 'Full-load transport', copy: 'Dedicated vehicle movement for larger commercial consignments and regular business routes.' },
  { number: '02', title: 'Business deliveries', copy: 'Reliable transport support for manufacturers, traders, distributors and growing enterprises.' },
  { number: '03', title: 'Planned & express movement', copy: 'Service shaped around your shipment priority, route and delivery timeline.' },
];

const LogisticsPage = () => (
  <main className="logistics-page">
    <nav className="logistics-nav">
      <a href="/" className="logistics-back"><ArrowLeft size={17} /> Veerashaiva Mart</a>
      <img src={velLogo} alt="Veerashaiva Express Logistics" />
      <a href="tel:+919155700900" className="logistics-call"><Phone size={16} /> Call us</a>
    </nav>

    <section className="logistics-hero" style={{ '--hero-image': `url(${heroImage})` }}>
      <div className="logistics-hero-shade" />
      <div className="logistics-hero-content">
        <p className="logistics-kicker"><Truck size={17} /> Veerashaiva Express Logistics</p>
        <h1>Your cargo.<br /><em>Our commitment.</em></h1>
        <p className="logistics-intro">Dependable road logistics from Udupi—built around safe handling, timely delivery and clear communication at every kilometre.</p>
        <div className="logistics-actions">
          <a className="logistics-primary" href="tel:+919155700900">Request a quote <ArrowRight size={18} /></a>
          <a className="logistics-secondary" href="#services">Explore services</a>
        </div>
        <div className="logistics-trust" aria-label="Service commitments">
          <span><CheckCircle2 size={17} /> Safe</span>
          <span><CheckCircle2 size={17} /> Timely</span>
          <span><CheckCircle2 size={17} /> Dependable</span>
        </div>
      </div>
    </section>

    <section className="promise-section">
      <div className="logistics-container">
        <div className="logistics-heading">
          <div><p className="logistics-kicker dark">The VEL promise</p><h2>Logistics you can<br /><em>plan around.</em></h2></div>
          <p>Every shipment represents a promise to your customer. We treat it with the attention, responsibility and urgency it deserves.</p>
        </div>
        <div className="promise-grid">
          {promises.map(({ icon: Icon, title, copy }) => <article key={title}><span><Icon size={24} /></span><h3>{title}</h3><p>{copy}</p></article>)}
        </div>
      </div>
    </section>

    <section id="services" className="services-section">
      <div className="logistics-container services-layout">
        <div className="services-copy">
          <p className="logistics-kicker"><PackageCheck size={17} /> Road freight solutions</p>
          <h2>Built for the way<br /><em>your business moves.</em></h2>
          <p>From recurring business deliveries to dedicated consignments, our approach stays simple: understand the requirement, plan responsibly and deliver with care.</p>
          <a href="tel:+919155700900">Discuss your shipment <ArrowRight size={18} /></a>
        </div>
        <div className="service-list">
          {services.map((service) => <article key={service.number}><span>{service.number}</span><div><h3>{service.title}</h3><p>{service.copy}</p></div></article>)}
        </div>
      </div>
    </section>

    <section className="logistics-cta">
      <div className="logistics-container">
        <p className="logistics-kicker">Ready when you are</p>
        <h2>Let’s move your next<br /><em>shipment with confidence.</em></h2>
        <a href="tel:+919155700900"><Phone size={18} /> Call +91 91557 00900</a>
      </div>
    </section>

    <footer className="logistics-footer logistics-container"><span>© {new Date().getFullYear()} Veerashaiva Express Logistics</span><a href="/">A Veerashaiva Mart company</a></footer>
  </main>
);

export default LogisticsPage;
