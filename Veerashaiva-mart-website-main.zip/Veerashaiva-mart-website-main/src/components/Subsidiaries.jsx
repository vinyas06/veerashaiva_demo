import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import blinkerImg from '../assets/blinker_logo.png';
import velImg from '../assets/vel_logo_clean.png';
import nirantharaImg from '../assets/niranthara_logo.png';
import coastalKingImg from '../assets/coastal_king_logo.png';
import infotechImg from '../assets/veerashaiva_infotech_logo.png';
import './Subsidiaries.css';

const brands = [
  { name: 'Blinker Beverages', type: 'Refreshment', desc: 'A bright, refreshing soft-drink brand for every occasion.', image: blinkerImg, className: 'brand-blinker', href: '/blinker/' },
  { name: 'Veerashaiva Express Logistics', type: 'Logistics', desc: 'Fast, safe and on-time delivery that keeps business moving.', image: velImg, className: 'brand-vel', href: '/veerashaiva-express-logistics/' },
  { name: 'Niranthara Magic', type: 'Masalas', desc: 'Pure veg masala powders that bring tradition into every kitchen.', image: nirantharaImg, className: 'brand-niranthara', href: '/niranthara/' },
  { name: 'Coastal King', type: 'Masalas', desc: 'South Indian spice blends packed with the taste of the coast.', image: coastalKingImg, className: 'brand-coastal', href: '/coastal-king/' },
  { name: 'Veerashaiva Infotech Technology', type: 'Technology', desc: 'Practical digital solutions designed to help modern businesses move forward.', image: infotechImg, className: 'brand-infotech', href: '/veerashaiva-infotech-technology/' },
];

const CardContents = ({ brand }) => (
  <>
    <div className="brand-art"><img src={brand.image} alt={`${brand.name} logo`} /></div>
    <div className="brand-copy">
      <p className="brand-type">{brand.type}</p>
      <h3>{brand.name}</h3>
      <p>{brand.desc}</p>
      {brand.href && <span className="brand-arrow"><ArrowUpRight size={20} /> <b>Explore</b></span>}
    </div>
  </>
);

const Subsidiaries = () => (
  <section id="brands" className="brands section-space">
    <div className="container">
      <div className="brands-header">
        <div>
          <p className="eyebrow">Our brands</p>
          <h2>One family of<br /><em>trusted names.</em></h2>
        </div>
        <p>Each brand has its own character, united by our commitment to quality and care.</p>
      </div>
      <div className="brands-grid">
        {brands.map((brand, index) => (
          <motion.article
            className={`brand-card ${brand.className} ${brand.href ? 'brand-card-link' : ''}`}
            key={brand.name}
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: index * 0.08 }}
          >
            {brand.href ? <a className="brand-card-action" href={brand.href} aria-label={`Explore ${brand.name}`}><CardContents brand={brand} /></a> : <CardContents brand={brand} />}
          </motion.article>
        ))}
      </div>
    </div>
  </section>
);

export default Subsidiaries;
