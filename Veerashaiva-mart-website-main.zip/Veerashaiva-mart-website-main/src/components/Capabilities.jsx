import { motion } from 'framer-motion';
import { CookingPot, Droplets, GlassWater, PackageCheck, Truck } from 'lucide-react';
import './Capabilities.css';

const capabilities = [
  { icon: PackageCheck, number: '01', title: 'PET Bottle Blowing', text: 'PET bottle solutions made to support dependable packaging needs.' },
  { icon: GlassWater, number: '02', title: 'Soft Drinks', text: 'Refreshing beverages created for everyday moments and growing markets.' },
  { icon: Droplets, number: '03', title: 'Cold-Pressed Coconut Oil', text: 'Pure coconut oil, gently made to preserve its natural goodness.' },
  { icon: CookingPot, number: '04', title: 'Masala Powders', text: 'Aromatic spice blends inspired by authentic South Indian flavour.' },
  { icon: Truck, number: '05', title: 'Logistics', text: 'Fast, safe and on-time movement for products that need to go further.' },
];

const Capabilities = () => (
  <section id="businesses" className="capabilities section-space">
    <div className="container">
      <div className="capabilities-heading">
        <div>
          <p className="eyebrow">What we do</p>
          <h2>From the factory floor to your everyday.</h2>
        </div>
        <p>We combine multiple capabilities to make and move products people use with confidence.</p>
      </div>
      <div className="capability-grid">
        {capabilities.map(({ icon: Icon, number, title, text }, index) => (
          <motion.article
            className="capability"
            key={title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.16 }}
            transition={{ duration: 0.45, delay: index * 0.07 }}
          >
            <div className="capability-top"><span>{number}</span><Icon size={26} strokeWidth={1.55} /></div>
            <h3>{title}</h3>
            <p>{text}</p>
          </motion.article>
        ))}
      </div>
    </div>
  </section>
);

export default Capabilities;
