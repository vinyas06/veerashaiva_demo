import { motion } from 'framer-motion';
import { BadgeCheck, Factory, MapPin } from 'lucide-react';
import './About.css';

const highlights = [
  { icon: Factory, label: 'Made for daily life', text: 'Thoughtfully produced essentials for homes and businesses.' },
  { icon: BadgeCheck, label: 'Quality-led', text: 'A clear focus on consistency, care and reliable service.' },
  { icon: MapPin, label: 'Rooted locally', text: 'Proudly operating from Havanje, Udupi, Karnataka.' },
];

const About = () => (
  <section id="about" className="about section-space">
    <div className="container about-layout">
      <motion.div
        className="about-intro"
        initial={{ opacity: 0, y: 22 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.55 }}
      >
        <p className="eyebrow">About Veerashaiva Mart</p>
        <h2>Built on the belief that <em>quality should feel close to home.</em></h2>
      </motion.div>
      <motion.div
        className="about-copy"
        initial={{ opacity: 0, y: 22 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.55, delay: 0.1 }}
      >
        <p>Veerashaiva Mart is a home-grown enterprise bringing practical products and services together under one trusted name. We manufacture everyday essentials and support their movement through dependable logistics.</p>
        <p>Our growing portfolio is shaped by an uncomplicated promise: make products people can rely on, and serve every customer with care.</p>
      </motion.div>
    </div>
    <div className="container about-highlights">
      {highlights.map(({ icon: Icon, label, text }, index) => (
        <motion.article
          className="highlight"
          key={label}
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45, delay: index * 0.09 }}
        >
          <span className="highlight-icon"><Icon size={22} strokeWidth={1.7} /></span>
          <div><h3>{label}</h3><p>{text}</p></div>
        </motion.article>
      ))}
    </div>
  </section>
);

export default About;
