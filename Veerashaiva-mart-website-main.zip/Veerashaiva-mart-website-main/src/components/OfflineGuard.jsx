import { useEffect, useState } from 'react';
import { ArrowLeft, RefreshCw, WifiOff } from 'lucide-react';
import mainLogo from '../assets/veerashaiva_logo.png';
import './OfflineGuard.css';

const OfflineGuard = ({ children }) => {
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);

  useEffect(() => {
    const showOnline = () => setIsOnline(true);
    const showOffline = () => setIsOnline(false);
    window.addEventListener('online', showOnline);
    window.addEventListener('offline', showOffline);
    return () => {
      window.removeEventListener('online', showOnline);
      window.removeEventListener('offline', showOffline);
    };
  }, []);

  if (isOnline) return children;

  return (
    <main className="offline-screen">
      <div className="offline-orbit orbit-one" aria-hidden="true" />
      <div className="offline-orbit orbit-two" aria-hidden="true" />
      <a className="offline-brand" href="/" aria-label="Veerashaiva Mart home">
        <img src={mainLogo} alt="" />
        <span>Veerashaiva<br />Mart</span>
      </a>
      <section className="offline-card">
        <span className="offline-icon"><WifiOff size={30} /></span>
        <p>Connection interrupted</p>
        <h1>You’re currently<br /><em>offline.</em></h1>
        <div className="offline-rule" />
        <p className="offline-copy">We couldn’t reach the internet. Your connection may be taking a short break—please check it and try again.</p>
        <div className="offline-actions">
          <button type="button" onClick={() => window.location.reload()}><RefreshCw size={17} /> Try again</button>
          <button className="offline-back" type="button" onClick={() => window.history.back()}><ArrowLeft size={17} /> Go back</button>
        </div>
      </section>
      <p className="offline-foot">Veerashaiva Mart · Udupi, Karnataka</p>
    </main>
  );
};

export default OfflineGuard;
