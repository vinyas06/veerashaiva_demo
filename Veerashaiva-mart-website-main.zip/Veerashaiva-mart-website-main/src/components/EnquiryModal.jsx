import { useEffect, useId, useState } from 'react';
import emailjs from '@emailjs/browser';
import { CheckCircle2, LoaderCircle, Send, X } from 'lucide-react';
import './EnquiryModal.css';

const initialValues = {
  fullName: '',
  phone: '',
  email: '',
  company: '',
  location: '',
  requirement: '',
  quantity: '',
};

const emailJsConfig = {
  serviceId: import.meta.env.VITE_EMAILJS_SERVICE_ID,
  ownerTemplateId: import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
  confirmationTemplateId: import.meta.env.VITE_EMAILJS_CONFIRMATION_TEMPLATE_ID,
  publicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
};

const getValidationErrors = (values) => {
  const errors = {};
  const phoneDigits = values.phone.replace(/\D/g, '');

  if (!values.fullName.trim()) errors.fullName = 'Please enter your full name.';
  if (!values.phone.trim()) errors.phone = 'Please enter your phone number.';
  else if (phoneDigits.length < 7) errors.phone = 'Please enter a valid phone number.';
  if (!values.email.trim()) errors.email = 'Please enter your email address.';
  else if (!/^\S+@\S+\.\S+$/.test(values.email)) errors.email = 'Please enter a valid email address.';
  if (!values.requirement.trim()) errors.requirement = 'Please tell us about your requirement.';

  return errors;
};

const getMissingConfiguration = () => {
  const missing = [];
  if (!emailJsConfig.serviceId) missing.push('EmailJS Service ID');
  if (!emailJsConfig.ownerTemplateId) missing.push('owner enquiry Template ID');
  if (!emailJsConfig.confirmationTemplateId) missing.push('confirmation Template ID');
  if (!emailJsConfig.publicKey) missing.push('EmailJS Public Key');
  return missing;
};

const EnquiryModal = ({ onClose }) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [submitState, setSubmitState] = useState('idle');
  const [submitMessage, setSubmitMessage] = useState('');
  const titleId = useId();
  const missingConfiguration = getMissingConfiguration();

  useEffect(() => {
    const closeOnEscape = (event) => {
      if (event.key === 'Escape' && submitState !== 'loading') onClose();
    };

    document.body.classList.add('modal-open');
    window.addEventListener('keydown', closeOnEscape);
    return () => {
      document.body.classList.remove('modal-open');
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [onClose, submitState]);

  const updateField = (event) => {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (errors[name]) setErrors((current) => ({ ...current, [name]: '' }));
    if (submitState !== 'idle') {
      setSubmitState('idle');
      setSubmitMessage('');
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const nextErrors = getValidationErrors(values);
    setErrors(nextErrors);
    setSubmitMessage('');

    if (Object.keys(nextErrors).length) return;
    if (missingConfiguration.length) {
      setSubmitState('error');
      setSubmitMessage(`The enquiry service still needs: ${missingConfiguration.join(', ')}.`);
      return;
    }

    const submissionDate = new Intl.DateTimeFormat('en-IN', {
      dateStyle: 'medium',
      timeStyle: 'short',
      timeZone: 'Asia/Kolkata',
    }).format(new Date());
    const templateParams = {
      to_email: 'vinyassharana06@gmail.com',
      reply_to: values.email.trim(),
      from_name: values.fullName.trim(),
      from_email: values.email.trim(),
      phone: values.phone.trim(),
      company: values.company.trim() || 'Not provided',
      location: values.location.trim() || 'Not provided',
      message: values.requirement.trim(),
      quantity: values.quantity.trim() || 'Not provided',
      submission_date: submissionDate,
      website_name: 'Veerashaiva Mart',
    };

    setSubmitState('loading');

    try {
      await emailjs.send(
        emailJsConfig.serviceId,
        emailJsConfig.ownerTemplateId,
        templateParams,
        { publicKey: emailJsConfig.publicKey },
      );

      try {
        await emailjs.send(
          emailJsConfig.serviceId,
          emailJsConfig.confirmationTemplateId,
          { ...templateParams, to_email: values.email.trim(), to_name: values.fullName.trim() },
          { publicKey: emailJsConfig.publicKey },
        );
        setSubmitState('success');
        setSubmitMessage('Thank you! Your enquiry has been submitted successfully. We will contact you soon.');
      } catch {
        setSubmitState('partial');
        setSubmitMessage('Your enquiry was received, but we could not send your confirmation email. We will still contact you soon.');
      }

      setValues(initialValues);
      setErrors({});
    } catch {
      setSubmitState('error');
      setSubmitMessage('We could not submit your enquiry right now. Please try again or call us at +91 91557 00900.');
    }
  };

  const isLoading = submitState === 'loading';

  return (
    <div className="enquiry-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && !isLoading && onClose()}>
      <section className="enquiry-modal" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <button className="enquiry-close" type="button" aria-label="Close enquiry form" onClick={onClose} disabled={isLoading}>
          <X size={21} aria-hidden="true" />
        </button>
        <div className="enquiry-intro">
          <p className="eyebrow">Start a conversation</p>
          <h2 id={titleId}>Tell us what you need.</h2>
          <p>Share your requirement and the Veerashaiva Mart team will get back to you.</p>
        </div>

        <form className="enquiry-form" noValidate onSubmit={handleSubmit}>
          <div className="enquiry-grid">
            <Field label="Full Name" name="fullName" value={values.fullName} error={errors.fullName} onChange={updateField} required autoComplete="name" />
            <Field label="Phone Number" name="phone" type="tel" value={values.phone} error={errors.phone} onChange={updateField} required autoComplete="tel" />
            <Field label="Email Address" name="email" type="email" value={values.email} error={errors.email} onChange={updateField} required autoComplete="email" />
            <Field label="Company / Business Name" name="company" value={values.company} error={errors.company} onChange={updateField} autoComplete="organization" />
            <Field label="Location" name="location" value={values.location} error={errors.location} onChange={updateField} autoComplete="address-level2" />
            <Field label="Quantity / Requirement Details" name="quantity" value={values.quantity} error={errors.quantity} onChange={updateField} />
          </div>
          <Field label="Requirement / Message" name="requirement" value={values.requirement} error={errors.requirement} onChange={updateField} required multiline />

          {submitMessage && (
            <p className={`form-message form-message-${submitState}`} role="status">
              {submitState === 'success' && <CheckCircle2 size={19} aria-hidden="true" />}
              {submitMessage}
            </p>
          )}

          <button className="enquiry-submit" type="submit" disabled={isLoading}>
            {isLoading ? <><LoaderCircle className="spinner" size={18} aria-hidden="true" /> Sending enquiry...</> : <><Send size={17} aria-hidden="true" /> Submit enquiry</>}
          </button>
        </form>
      </section>
    </div>
  );
};

const Field = ({ label, name, type = 'text', value, error, onChange, required = false, multiline = false, autoComplete }) => {
  const fieldId = `enquiry-${name}`;
  const commonProps = {
    id: fieldId,
    name,
    value,
    onChange,
    required,
    autoComplete,
    'aria-invalid': Boolean(error),
    'aria-describedby': error ? `${fieldId}-error` : undefined,
  };

  return (
    <label className={`enquiry-field ${multiline ? 'enquiry-field-wide' : ''}`} htmlFor={fieldId}>
      <span>{label}{required && <b aria-hidden="true"> *</b>}</span>
      {multiline ? <textarea {...commonProps} rows="4" /> : <input {...commonProps} type={type} />}
      {error && <small id={`${fieldId}-error`}>{error}</small>}
    </label>
  );
};

export default EnquiryModal;
